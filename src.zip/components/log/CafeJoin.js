import React, {useRef, useState, useEffect} from "react";
import { useNavigate } from "react-router-dom";
import CafeManagerInfo from "../log/CafeManagerInfo.js";
import "../css/CafeJoin.css"


function CafeJoin() {
    // 가입 유형
    const [option, setOption] = useState("user");
    // 아이디 중복 체크 여부
    const [isIdAvailable, setIsIdAvailable] = useState(""); 
    //타이틀 출력
    const [titleSub, setTitleSub] = useState("user"); 

    useEffect(() => {
        setTitleSub("일반회원");
    }, []);

    const userid = useRef();
    const passwd = useRef();
    const name = useRef();
    const email = useRef();
    const tel = useRef();
    
    // 카페 매니저 데이터
    const cafeManagerInfoRef = useRef(); 

    const navigate = useNavigate();

    // 가입 유형 선택 시 변경
    const handleOptionChange = (e) => {
        const selectedOption = e.target.value;
        setOption(e.target.value);

        // ✅ 가입 유형에 따라 titleSub 변경
        if (selectedOption === "user") {
            setTitleSub("일반회원");
        } else if (selectedOption === "manager") {
            setTitleSub("카페매니저");
        }
    };

    // 아이디 중복체크  
    const handleIdCheck = async () => {
        if (!userid.current.value) {
            alert("아이디를 입력하세요.");
            userid.current.focus();
            return;
        }

        
        console.log("입력한 아이디:", userid.current.value); 
        console.log("입력한 옵션:", option); 

        const response = await fetch ("http://localhost/api/member/idCheck", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({userid: userid.current.value , option}),

        });

        
        
        const result = await response.json();
        console.log("서버응답:", result);
        if (result.status === "available") {
            alert("사용가능한 아이디입니다.")
            setIsIdAvailable(true);
        } else {
            alert("이미 존재하는 아이디입니다.")
            setIsIdAvailable(false); 
        }   
    };
   
    // 회원가입
    const handleJoin = async() => {
        if (!userid.current.value || !passwd.current.value || !name.current.value || !email.current.value || !tel.current.value) {
            alert("필수 정보를 입력하세요.");
            return;
        }

        if (!option) {
            alert("가입유형을 선택해주세요.");
            return;
        }

        if (!isIdAvailable) {
            alert("아이디 중복체크를 해주세요.");
            return;
        }

        const au_lv = option === "manager" ? 1 : 2;  // Manager = 1, User = 2


        const params = {
            userid: userid.current.value,
            passwd: passwd.current.value,
            name: name.current.value,
            email: email.current.value,
            tel: tel.current.value,
            option,
            au_lv,
        };

        if (option === "manager") {
            Object.assign(params, cafeManagerInfoRef.current.getCafeData());
        }

        console.log("보낼 회원가입 데이터:", params); 
    

        const response = await fetch("http://localhost/api/member/join", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(params),
        });
             

        const result = await response.json();
        console.log("서버 응답 데이터:", result);

        if (result.status === "success") {
            alert(result.message);
            navigate("/member/login");
        } else {
            alert(result.message);   
        }
    };

    return (
        <>
        <div className="container">
            <div className="maintitle">
                <div  className="intitle">
                    <h2 id="titleMain">회원가입</h2>
                    <h2 id="titleSub">{titleSub}</h2>
                </div>
            </div>
            <div>
                <table border={"1"} style={{ width: "600px" }}>
                    <tbody>
                        <tr>
                            <td>가입 유형</td>
                            <td style={
                                {width:"200px"}} colSpan={"2"} className="signup-option">
                                <label>
                                    <input type="radio" name="option" value="user" checked={option === "user"} onChange={handleOptionChange} /> 일반 회원
                                </label>
                                <label>
                                    <input type="radio" name="option" value="manager" checked={option === "manager"} onChange={handleOptionChange} /> 카페 매니저
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <td>아이디</td>
                            <td ><input style={{ width: "100%", boxSizing: "border-box" }} name="userid" ref={userid} /></td>
                            <td style={{ width: "75px", textAlign: "center" }}><button onClick={handleIdCheck}>중복 체크</button></td>
                        </tr>
                        <tr>
                            <td>비밀번호</td>
                            <td colSpan="2"><input style={{ width: "100%", boxSizing: "border-box" }} name="passwd" type="password" ref={passwd} /></td>
                        </tr>
                        <tr>
                            <td>이름</td>
                            <td colSpan="2"><input style={{ width: "100%", boxSizing: "border-box" }} name="name" ref={name} /></td>
                        </tr>
                        <tr>
                            <td style={{ width: "120px"}}>이메일(e-mail)</td>
                            <td colSpan="2"><input style={{ width: "100%", boxSizing: "border-box" }} name="email" ref={email} /></td>
                        </tr>
                        <tr>
                            <td>연락처</td>
                            <td colSpan="2"><input style={{ width: "100%", boxSizing: "border-box" }}  name="tel" ref={tel} /></td>
                        </tr>
                    </tbody>
                </table>
            </div>
                { option === "manager" && <CafeManagerInfo ref={cafeManagerInfoRef}/>}

                <button style={{marginTop:"10px"}} onClick={handleJoin}>회원가입</button>

            </div>
        </>
    );
}

export default CafeJoin;
