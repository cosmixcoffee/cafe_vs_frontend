import React, { useRef, useEffect, forwardRef, useImperativeHandle } from "react";
import "../css/CafeManagerInfo.css";

// ✅ forwardRef를 사용하여 ref 전달 가능하게 설정
const CafeManagerInfo = forwardRef((props, ref) => {
    const cf_name = useRef();
    const cf_pcode = useRef();
    const cf_adr1 = useRef();
    const cf_adr2 = useRef();
    const cf_tel = useRef();

    // 🚀 Daum 주소 API 로드
    useEffect(() => {
        if (!window.daum) {
            const script = document.createElement("script");
            script.src = "https://t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js";
            script.async = true;
            document.body.appendChild(script);

            script.onload = () => {
                console.log("🚀 Daum 주소 API 로드 완료");
            };
        }
    }, []);

    // 주소찾기 버튼 클릭 시 Daum 주소 API 호출
    const handlePostcode = () => {
        if (!window.daum || !window.daum.Postcode) {
            alert("주소 검색 API가 로드되지 않았습니다. 페이지를 새로고침 해주세요.");
            return;
        }

        new window.daum.Postcode({
            oncomplete: (data) => {
                let fullAddr = data.roadAddress || data.jibunAddress;
                let extraAddr = data.bname || "";

                if (data.buildingName) {
                    extraAddr += (extraAddr ? ", " + data.buildingName : data.buildingName);
                }
                fullAddr += (extraAddr ? " (" + extraAddr + ")" : "");

                cf_pcode.current.value = data.zonecode;
                cf_adr1.current.value = fullAddr;
                cf_adr2.current.focus();
            },
        }).open();
    };

    // ✅ `useImperativeHandle`을 사용하여 `getCafeData()`를 외부에서 호출 가능하도록 설정
    useImperativeHandle(ref, () => ({
        getCafeData: () => ({
            cf_name: cf_name.current.value,
            cf_pcode: cf_pcode.current.value,
            cf_adr1: cf_adr1.current.value,
            cf_adr2: cf_adr2.current.value,
            cf_tel: cf_tel.current.value,
        }),
    }));


    return (
      <>
        <div className="infocontainer">
            <div className="infomaintitle">
                <div className="intitle">
                    <h2 id="titleMain">CAFE</h2>
                </div>
            </div>
            <div>
                <table border={"1"} style={{ width: "600px" }}>
                    <tbody>
                        <tr>
                            <td>카페명</td>
                            <td colSpan="2" style={
                                {width:"300px"}}><input style={{ width: "100%", boxSizing: "border-box" }} type="text" name="cf_name" ref={cf_name} /></td>
                        </tr>
                        <tr>
                            <td>우편번호</td>
                            <td><input type="text" style={{ width: "100%", boxSizing: "border-box" }} name="cf_pcode" ref={cf_pcode} readOnly /></td>
                            <td style={{ width: "70px"}}><button onClick={handlePostcode} style={{ width: "75px", textAlign: "center" }}>주소 찾기</button></td>
                        </tr>
                        <tr>
                            <td>주소</td>
                            <td colSpan={"2"}><input style={{ width: "100%", boxSizing: "border-box" }} type="text" name="cf_adr1" ref={cf_adr1} readOnly /></td>
                        </tr>
                        <tr>
                            <td>상세 주소</td>
                            <td  colSpan={"2"}><input style={{ width: "100%", boxSizing: "border-box" }} type="text" name="cf_adr2" ref={cf_adr2} />
                            </td>
                        </tr>
                        <tr>
                            <td style={{ width: "120px"}}>카페 연락처</td>
                            <td  colSpan={"2"}><input style={{ width: "100%", boxSizing: "border-box" }} type="text" name="cf_tel" ref={cf_tel}  />
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
      </>  
    );
});

export default CafeManagerInfo;