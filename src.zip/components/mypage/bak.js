import React, { useEffect, useState } from "react";
import Cookies from "universal-cookie";
import "../css/BoardView.css";

const BoardView = ({ selectedIdx, setActiveComponent }) => {
    const cookies = new Cookies();
    const [post, setPost] = useState(null);
    const [comments, setComments] = useState([]);
    const [newComment, setNewComment] = useState("");
    const [uploadedFiles, setUploadedFiles] = useState([]);
    const [error, setError] = useState(null);
    const [isEditing, setIsEditing] = useState(false);
    const [editedTitle, setEditedTitle] = useState("");
    const [editedContents, setEditedContents] = useState("");
    const userid = cookies.get("userid");

    useEffect(() => {
        if (!selectedIdx) {
            setError("잘못된 접근입니다.");
            return;
        }

        Promise.all([
            fetch(`http://localhost/api/board/view?idx=${selectedIdx}`).then((res) => res.json()),
            fetch(`http://localhost/api/reply/list?idx=${selectedIdx}`).then((res) => res.json()),
            fetch(`http://localhost/api/board/list_attach/${selectedIdx}`).then((res) => res.json()),
        ])
            .then(([postData, commentData, attachmentData]) => {
                if (postData.dto) {
                    setPost(postData.dto);
                    setEditedTitle(postData.dto.title);
                    setEditedContents(postData.dto.contents);
                } else {
                    setError("게시글 데이터를 불러오지 못했습니다.");
                }

                setComments(commentData.length ? commentData : []);
                setUploadedFiles(attachmentData || []);
            })
            .catch(() => setError("데이터를 불러오는 중 오류가 발생했습니다."));
    }, [selectedIdx]);


    
    // 🔥 댓글 추가
    const handleCommentSubmit = () => {
        if (!newComment.trim()) {
            alert("댓글을 입력하세요.");
            return;
        }

        fetch("http://localhost/api/reply/insert", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ board_idx: selectedIdx, reply_text: newComment }),
            credentials: "include",
        })
            .then(() => {
                setNewComment("");  // 댓글 입력창 초기화
                fetch(`http://localhost/api/reply/list?idx=${selectedIdx}`)
                    .then((res) => res.json())
                    .then((data) => setComments(data || []));  // 댓글 목록 갱신
            })
            .catch(() => alert("댓글 등록 중 오류 발생"));
    };

    // 🔥 댓글 삭제
    const handleCommentDelete = (commentId) => {
        if (!window.confirm("댓글을 삭제하시겠습니까?")) return;

        fetch(`http://localhost/api/reply/delete/${commentId}`, {
            method: "DELETE",
            credentials: "include",
        })
            .then(() => {
                setComments(comments.filter((comment) => comment.idx !== commentId)); // 댓글 삭제
            })
            .catch(() => alert("댓글 삭제 중 오류 발생"));
    };
    

    return (
        <div className="view_board-container">
            <div className="view_title-section">
                <h2>건의사항</h2>
                <h3>상세보기</h3>
            </div>

            {error && <p style={{ color: "red" }}>{error}</p>}
            {!post ? (
                <p>게시글을 불러오는 중...</p>
            ) : (
                <div>
                    <table className="view_table">
                        <tbody>
                            <tr>
                                <td className="view_label">작성자</td>
                                <td>{post?.writer || "정보 없음"}</td>
                                <td className="view_label">조회수</td>
                                <td>{post?.hit || 0}</td>
                            </tr>
                            <tr>
                                <td className="view_label">제목</td>
                                <td colSpan="3">
                                    <input type="text" value={editedTitle} onChange={(e) => setEditedTitle(e.target.value)} />
                                </td>
                            </tr>
                            <tr>
                                <td className="view_label">내용</td>
                                <td colSpan="3">
                                    <textarea value={editedContents} onChange={(e) => setEditedContents(e.target.value)} />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    
                    {/* 🔥 댓글 입력 */}
                    <div className="view_comments-section">
                        <h3>댓글</h3>
                        {userid && (
                            <div className="view_comment-input">
                                <textarea
                                    value={newComment}
                                    onChange={(e) => setNewComment(e.target.value)}
                                    placeholder="댓글을 입력하세요."
                                />
                                <button onClick={handleCommentSubmit}>등록</button>
                            </div>
                        )}

                        {/* 🔥 댓글 목록 */}
                        <div className="view_comments-list">
                            {comments.length > 0 ? (
                                comments.map((comment) => (
                                    <div key={comment.idx} className="view_comment">
                                        <strong>{comment.replyer}</strong>: {comment.reply_text}
                                        {/* 댓글 수정/삭제 */}
                                        {comment.replyer === userid && (
                                            <div>
                                                <button onClick={() => handleCommentDelete(comment.idx)}>삭제</button>
                                            </div>
                                        )}
                                    </div>
                                ))
                            ) : (
                                <p>댓글이 없습니다.</p>
                            )}
                        </div>
                    </div>

                    {/* 🔥 버튼 */}
                    <div className="view_buttons">
                        <button onClick={handlePostSave}>수정</button>
                        <button onClick={handlePostDelete}>삭제</button>
                        <button onClick={() => setActiveComponent("board")}>목록</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default BoardView;
