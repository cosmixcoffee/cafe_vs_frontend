import React, { useState, useEffect } from "react";
import Cookies from "universal-cookie";


const BoardWrite = ({ setActiveComponent }) => {
    const [title, setTitle] = useState("");
    const [contents, setContents] = useState("");
    const [uploadedFiles, setUploadedFiles] = useState([]);

    const cookies = new Cookies();
    const userid = cookies.get("userid");

    useEffect(() => {
        if (!userid) {
            alert("로그인이 필요합니다.");
        }
    }, [userid]);

    // 🔥 파일 업로드 처리 (드래그 앤 드롭)
    const handleFileDrop = (e) => {
        e.preventDefault();
        const files = e.dataTransfer.files;

        if (files.length > 0) {
            const formData = new FormData();
            formData.append("file", files[0]);

            fetch("http://localhost/api/upload/ajax_upload", {
                method: "POST",
                body: formData,
                credentials: "include",
            })
                .then((res) => res.text())
                .then((filePath) => {
                    console.log("📁 업로드된 파일:", filePath);

                    // ✅ 파일명만 추출하여 저장 (경로 제거)
                    const fileName = filePath.split("/").pop();
                    setUploadedFiles((prev) => [...prev, fileName]);
                })
                .catch((error) => {
                    console.error("파일 업로드 실패:", error);
                });
        }
    };

    // 🔥 파일 삭제 처리
    const handleFileDelete = (fileName) => {
        if (!window.confirm("첨부파일을 삭제하시겠습니까?")) return;

        fetch(`http://localhost/api/upload/delete_file?file_name=${encodeURIComponent(fileName)}`, {
            method: "DELETE",
        })
            .then((res) => {
                if (!res.ok) {
                    throw new Error("파일 삭제 실패");
                }
                setUploadedFiles(uploadedFiles.filter((file) => file !== fileName));
            })
            .catch(() => alert("파일 삭제 중 오류 발생"));
    };

    function handleSubmit(e) {
        e.preventDefault();

        if (!title.trim()) {
            alert("제목을 입력하세요.");
            return;
        }
        if (!contents.trim()) {
            alert("내용을 입력하세요.");
            return;
        }
        if (!userid) {
            alert("로그인이 필요합니다.");
            return;
        }

        const postData = {
            title,
            contents,
            writer: userid,
            files: uploadedFiles, // ✅ 업로드된 파일 정보 저장
        };

        fetch("http://localhost/api/board/write", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            credentials: "include",
            body: JSON.stringify(postData),
        })
            .then((res) => {
                if (!res.ok) throw new Error("글 작성 실패");
                return res.text();
            })
            .then(() => {
                alert("글이 성공적으로 등록되었습니다.");
                setActiveComponent("board");
            })
            .catch((error) => {
                console.error("글 작성 오류:", error);
                alert("글 작성에 실패했습니다.");
            });
    }

    return (
        <div className="board-write-container">
            <div className="title-section">
                <h2>건의사항</h2>
                <h3>글쓰기</h3>
            </div>
            <form onSubmit={handleSubmit}>
                <table border={"1"}>
                    <tbody>
                        <tr>
                            <td>제목</td>
                            <td>
                                <input
                                    type="text"
                                    name="title"
                                    id="title"
                                    value={title}
                                    onChange={(e) => setTitle(e.target.value)}
                                    placeholder="제목을 입력하세요."
                                    style={{ width: "100%", boxSizing: "border-box" }}
                                />
                            </td>
                        </tr>
                        <tr>
                            <td>내용</td>
                            <td>
                                <textarea
                                    rows="5"
                                    id="contents"
                                    name="contents"
                                    value={contents}
                                    onChange={(e) => setContents(e.target.value)}
                                    placeholder="내용을 입력하세요"
                                    style={{ width: "100%", boxSizing: "border-box" }}
                                />
                            </td>
                        </tr>
                    </tbody>
                </table>

                {/* 🔥 파일 업로드 (드래그 앤 드롭) */}
                <div align="center">
                    <div
                        className="fileDrop"
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={handleFileDrop}
                        style={{ border: "2px dashed #ccc", padding: "20px", textAlign: "center", marginTop: "10px" }}
                    >
                        여기에 첨부할 파일을 올려놓으세요.
                    </div>

                    {/* 🔥 업로드된 파일 목록 */}
                    <div id="uploadedList">
                        {uploadedFiles.map((file, index) => (
                            <div key={index} className="uploaded-file">
                                <span>{file}</span>
                                <button type="button" onClick={() => handleFileDelete(file)}>삭제</button>
                            </div>
                        ))}
                    </div>

                    <button type="submit" id="btnSave">
                        확인
                    </button>
                </div>
            </form>
        </div>
    );
};

export default BoardWrite;
