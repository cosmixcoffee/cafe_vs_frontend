import React, { useEffect, useState } from "react";
import Cookies from "universal-cookie";
import "../css/BoardView.css";
import CommentsList from "./BoardCommList";

const BoardView = ({ selectedIdx, setActiveComponent }) => {
    const cookies = new Cookies();
    const [post, setPost] = useState(null);
    const [comments, setComments] = useState([]);
    const [newComment, setNewComment] = useState("");
    const [uploadedFiles, setUploadedFiles] = useState([]);
    const [error, setError] = useState(null);
    const [isEditing, setIsEditing] = useState(false);
    const [editedTitle, setEditedTitle] = useState("");
    const [editedContents, setEditedContents] = useState("");
    const userid = cookies.get("userid");
    const user_au_lv = cookies.get("user_au_lv");





    useEffect(() => {
        if (!selectedIdx) {
            setError("잘못된 접근입니다.");
            return;
        }

        Promise.all([
            fetch(`http://localhost/api/board/view?idx=${selectedIdx}`)
                .then((res) => res.json()),

            fetch(`http://localhost/api/reply/list?board_idx=${selectedIdx}`, {
                credentials: "include",  // ✅ 댓글 리스트는 쿠키 포함 (권한 체크)
            })
                .then((res) => res.json()),

            fetch(`http://localhost/api/board/list_attach/${selectedIdx}`)
                .then((res) => res.json()),
        ])
            .then(([postData, commentData, attachmentData]) => {
                if (postData.dto) {
                    setPost(postData.dto);
                } else {
                    setError("게시글 데이터를 불러오지 못했습니다.");
                }

                if (commentData.error) {
                    setError("댓글 데이터를 불러오지 못했습니다.");
                } else {
                    setComments(commentData.length ? commentData : []);
                }

                setUploadedFiles(attachmentData || []);
            })
            .catch(() => setError("데이터를 불러오는 중 오류가 발생했습니다."));
    }, [selectedIdx]);


    /** 🔥 파일 업로드 (드래그 앤 드롭 + DB 저장) */
    const handleFileDrop = async (event) => {
        event.preventDefault();
        const files = event.dataTransfer.files;

        if (files.length === 0) return;

        // ✅ 기존 파일 삭제 먼저 수행 (DB 삭제 포함)
        await Promise.all(uploadedFiles.map(file => handleFileDelete(file, true))); // 자동 삭제 플래그

        // ✅ 새 파일 업로드 (URL 수정)
        const formData = new FormData();
        formData.append("file", files[0]);

        fetch("http://localhost/api/upload/ajax_upload", { // ✅ 수정된 URL
            method: "POST",
            body: formData,
        })
            .then(res => res.text())
            .then(fileName => {
                console.log("📂 업로드 성공:", fileName);

                // ✅ DB에도 파일 저장 (URL 수정)
                fetch(`http://localhost/api/board/update_attach`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        file_name: fileName,
                        idx: selectedIdx, // 현재 게시글 번호
                    }),
                    credentials: "include",
                })
                    .then(() => {
                        setUploadedFiles([fileName]); // 기존 파일 삭제 후 새 파일만 유지
                    })
                    .catch(() => alert("DB 저장 중 오류 발생"));
            })
            .catch(() => alert("파일 업로드 중 오류 발생"));
    };




    /** 🔥 파일 삭제 */
    const handleFileDelete = (fileName) => {
        if (!window.confirm("첨부파일을 삭제하시겠습니까?")) return;

        const relativeFilePath = fileName.split("/").pop(); // 파일명만 추출

        fetch(`http://localhost/api/upload/delete_file?file_name=${encodeURIComponent(relativeFilePath)}`, {
            method: "DELETE",
            credentials: "include",
        })
            .then((res) => {
                if (res.status === 404) {
                    alert("파일을 찾을 수 없습니다. 이미 삭제되었을 수 있습니다.");
                    return;
                }
                if (!res.ok) throw new Error("파일 삭제 실패");

                setUploadedFiles(uploadedFiles.filter((file) => file !== fileName));
                alert("파일이 삭제되었습니다.");
            })
            .catch(() => alert("파일 삭제 중 오류 발생"));
    };



    const handleCommentSubmit = () => {
        if (!newComment.trim()) {
            alert("댓글을 입력하세요.");
            return;
        }
    
        const user_au_lv = cookies.get("user_au_lv");
    
        fetch("http://localhost/api/reply/insert", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                board_idx: selectedIdx,
                reply_text: newComment.trim(), // ✅ 공백 제거 후 전송
            }),
            credentials: "include", // ✅ 쿠키 자동 포함
        })
            .then((res) => res.text())
            .then((data) => {
                if (data === "success") {
                    // ✅ 새 댓글 객체 생성
                    const newCommentObj = {
                        idx: Date.now(), // ✅ 임시 ID (실제 서버 ID는 나중에 반영됨)
                        replyer: cookies.get("userid"),
                        reply_text: newComment.trim(),
                        regdate: new Date().toISOString(),
                    };
    
                    // ✅ 기존 댓글 목록에 새 댓글 추가 (화면 즉시 반영)
                    setComments((prevComments) => [newCommentObj, ...prevComments]);
    
                    // ✅ 입력창 초기화
                    setNewComment("");
    
                    // ✅ 서버에서 최신 목록 불러와 동기화 (최신 댓글 반영)
                    fetch(`http://localhost/api/reply/list?board_idx=${selectedIdx}`, {
                        credentials: "include",
                    })
                        .then((res) => res.json())
                        .then((data) => setComments(data || [])) // ✅ 서버 데이터로 최종 업데이트
                        .catch(() => alert("댓글 갱신 중 오류 발생"));
                } else {
                    alert("댓글 등록 실패: " + data);
                }
            })
            .catch(() => alert("댓글 등록 중 오류 발생"));
    };
    




    // 🔥 댓글 삭제
    const handleCommentDelete = (commentId) => {
        if (!window.confirm("댓글을 삭제하시겠습니까?")) return;

        fetch(`http://localhost/api/reply/delete/${commentId}`, {
            method: "DELETE",
            headers: { "Content-Type": "application/json" },
            credentials: "include",
        })
            .then((res) => {
                if (!res.ok) {
                    throw new Error(`HTTP error! status: ${res.status}`);
                }
                return res.json(); // ✅ JSON 응답으로 처리
            })
            .then((data) => {
                if (data.status === "success") {
                    setComments(comments.filter((comment) => comment.idx !== commentId)); // ✅ 삭제 성공 시 UI 업데이트
                } else {
                    throw new Error("삭제 실패");
                }
            })
            .catch((error) => {
                console.error("댓글 삭제 중 오류 발생:", error);
                alert("댓글 삭제 실패: " + error.message);
            });
    };



    /** 🔥 게시글 수정 */
    const handlePostSave = () => {
        fetch(`http://localhost/api/board/update.do`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                idx: selectedIdx,
                title: editedTitle,
                contents: editedContents
            }),
            credentials: "include",
        })
            .then(() => {
                setPost({ ...post, title: editedTitle, contents: editedContents });
                alert("게시글이 수정되었습니다.");
            })
            .catch(() => alert("게시글 수정 중 오류 발생"));
    };

    /** 🔥 게시글 삭제 */
    const handlePostDelete = () => {
        if (!window.confirm("정말로 삭제하시겠습니까?")) return;
        fetch(`http://localhost/api/board/delete/${selectedIdx}`, {
            method: "DELETE",
            credentials: "include",
        })
            .then(() => {
                alert("게시글이 삭제되었습니다.");
                setActiveComponent("board");
            })
            .catch(() => alert("게시글 삭제 중 오류 발생"));
    };

    return (
        <div className="view_board-container">
            <div className="view_title-section">
                <h2>건의사항</h2>
                <h3>상세보기</h3>
            </div>

            {error && <p style={{ color: "red" }}>{error}</p>}
            {!post ? (
                <p>게시글을 불러오는 중...</p>
            ) : (
                <div>
                    <table className="view_table">
                        <tbody>
                            <tr>
                                <td className="view_label">작성자</td>
                                <td>{post?.writer || "정보 없음"}</td>
                                <td className="view_label">조회수</td>
                                <td>{post?.hit || 0}</td>
                            </tr>
                            <tr>
                                <td className="view_label">제목</td>
                                <td colSpan="3">
                                    <input type="text" value={editedTitle} onChange={(e) => setEditedTitle(e.target.value)} />
                                </td>
                            </tr>
                            <tr>
                                <td className="view_label">내용</td>
                                <td colSpan="3">
                                    <textarea value={editedContents} onChange={(e) => setEditedContents(e.target.value)} />
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    {/* 🔥 파일 업로드 (드래그 앤 드롭) */}
                    <div className="view_files">
                        <h3>첨부 파일</h3>
                        <div
                            className="fileDrop"
                            onDrop={handleFileDrop}
                            onDragOver={(e) => e.preventDefault()}
                            style={{ border: "2px dashed #ccc", padding: "20px", textAlign: "center", marginTop: "10px" }}
                        >
                            파일을 여기로 드래그하세요
                        </div>

                        {uploadedFiles.length > 0 ? (
                            uploadedFiles.map((file, index) => (
                                <div key={index} className="view_attachment">
                                    <a href={`http://localhost/upload/api/display_file?file_name=${file}`} target="_blank" rel="noopener noreferrer">
                                        {file}
                                    </a>
                                    <button onClick={() => handleFileDelete(file)}>삭제</button>
                                </div>
                            ))
                        ) : (
                            <p>첨부파일이 없습니다.</p>
                        )}
                    </div>
                    {/* 🔥 댓글 입력 */}
                    <div className="view_comments-section">
                        <h3>댓글</h3>
                        {userid && (
                            <div className="view_comment-input">
                                <textarea
                                    value={newComment}
                                    onChange={(e) => setNewComment(e.target.value)}
                                    placeholder="댓글을 입력하세요."
                                />
                                <button onClick={handleCommentSubmit}>등록</button>
                            </div>
                        )}

                        {/* 🔥 댓글 목록 */}
                        <div className="view_comments-list">
                            {/* ✅ 기존 `comments.map(...)`을 삭제하고, 페이징이 적용된 `CommentsList`만 사용 */}
                            <CommentsList comments={comments} userid={userid} handleCommentDelete={handleCommentDelete} />
                        </div>

                    </div>

                    {/* 🔥 버튼 */}
                    <div className="view_buttons">
                        <button onClick={handlePostSave}>수정</button>
                        <button onClick={handlePostDelete}>삭제</button>
                        <button onClick={() => setActiveComponent("board")}>목록</button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default BoardView;
