import React, { useState } from "react";

const CommentsList = ({ comments, userid, handleCommentDelete }) => {
    const [currentPage, setCurrentPage] = useState(1);
    const commentsPerPage = 10; // ✅ 한 페이지에 10개씩 표시

    // ✅ 현재 페이지의 댓글만 가져오기
    const indexOfLastComment = currentPage * commentsPerPage;
    const indexOfFirstComment = indexOfLastComment - commentsPerPage;
    const currentComments = comments.slice(indexOfFirstComment, indexOfLastComment);

    // ✅ 페이지 변경 함수
    const paginate = (pageNumber) => setCurrentPage(pageNumber);

    return (
        <div>
            <h3>댓글 목록</h3>
            <div className="view_comments-list">
                {currentComments.length > 0 ? (
                    currentComments.map((comment) => (
                        <div key={comment.idx} className="view_comment">
                            <strong>{comment.replyer}</strong>: {comment.reply_text}
                            {comment.replyer === userid && (
                                <div>
                                    <button onClick={() => handleCommentDelete(comment.idx)}>삭제</button>
                                </div>
                            )}
                        </div>
                    ))
                ) : (
                    <p>댓글이 없습니다.</p>
                )}
            </div>

            {/* ✅ 페이징 버튼 */}
            <div className="pagination">
                {Array.from({ length: Math.ceil(comments.length / commentsPerPage) }, (_, i) => i + 1).map((number) => (
                    <button key={number} onClick={() => paginate(number)} className={number === currentPage ? "active" : ""}>
                        {number}
                    </button>
                ))}
            </div>
        </div>
    );
};

export default CommentsList;
