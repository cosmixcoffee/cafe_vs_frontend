import React, { useEffect, useState } from "react";
import axios from "axios";
import ReplyDetail from "./ReplyDetail";
import "../css/ReplyList.css";
import Cookies from "universal-cookie";
import ReplyList from "./ReplyList";

const BoardView = ({ selectedIdx, setActiveComponent }) => {
    const cookies = new Cookies();
    const [post, setPost] = useState(null);
    const userid = cookies.get("userid");

    useEffect(() => {
        fetchPost();
    }, [selectedIdx]);

    const fetchPost = async () => {
        try {
            const response = await axios.get(`http://localhost/api/board/view?idx=${selectedIdx}`);
            setPost(response.data.dto);
        } catch (error) {
            console.error("게시글 불러오기 실패:", error);
        }
    };

    return (
        <div className="board-view-container">
            {post ? (
                <>
                    <h2>{post.title}</h2>
                    <p>{post.contents}</p>
                    <p><strong>작성자:</strong> {post.writer}</p>
                    <p><strong>조회수:</strong> {post.hit}</p>
                    <button onClick={() => setActiveComponent("board")}>목록으로</button>
                    <hr />
                    {/* 댓글 리스트 추가 */}
                    <ReplyList boardIdx={selectedIdx} />
                </>
            ) : (
                <p>게시글을 불러오는 중...</p>
            )}
        </div>
    );
};

export default BoardView;
