import React, { useEffect, useState } from "react";
import Cookies from "universal-cookie";
import "../css/ansList.css";

const BoardList = ({ setActiveComponent, setSelectedIdx }) => {
    const [posts, setPosts] = useState([]);
    const [page_info, setPageInfo] = useState(null);
    const [search_option, setSearchOption] = useState("all");
    const [keyword, setKeyword] = useState("");
    const [error, setError] = useState(null);
    const [count, setCount] = useState(0);
    const cookies = new Cookies(); // ✅ 쿠키 인스턴스 생성

    const userid = cookies.get("userid");
    const user_au_lv = cookies.get("user_au_lv");

    useEffect(() => {
        fetchPosts(1);
    }, []);

    const handleTitleClick = (idx) => {
        setSelectedIdx(idx);  // ✅ 클릭된 게시글 ID 저장
        setActiveComponent("view");  // ✅ 상세 페이지로 이동
    };


    const fetchPosts = (curPage) => {
        fetch(`http://localhost/api/board/list?curPage=${curPage}&search_option=${search_option}&keyword=${keyword}`, {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
                "userid": userid,          // ✅ 쿠키에서 가져온 userid 추가
                "user_au_lv": user_au_lv,  // ✅ 쿠키에서 가져온 user_au_lv 추가
            },
            credentials: "include",  // ✅ 쿠키 포함하여 요청
        })
            .then((response) => {
                if (!response.ok) {
                    throw new Error("서버 응답 오류");
                }
                return response.json();
            })
            .then((data) => {
                console.log("📌 서버 응답 데이터:", data); // ✅ 응답 데이터를 콘솔에서 확인
    
                if (data.error) {
                    setError(data.error);
                } else {
                    setPosts(data.list);
                    setPageInfo(data.page_info);
                    setCount(data.count);
                }
            })
            .catch((error) => {
                console.error("게시글을 불러오는 중 오류 발생:", error);
                setError("게시글을 불러올 수 없습니다.");
            });
    };
    

    const handleSearch = (e) => {
        e.preventDefault();
        fetchPosts(1);
    };

    return (
        <div className="board-container">
            {/* 건의사항 제목 왼쪽 정렬 */}
            <div className="board-header">
                <h2>건의사항</h2>
            </div>

            {error && <p style={{ color: "red" }}>{error}</p>}

            {/* 검색 폼 */}
            <form className="board-search" onSubmit={handleSearch}>
                <select value={search_option} onChange={(e) => setSearchOption(e.target.value)}>
                    <option value="all">이름+제목</option>
                    <option value="name">이름</option>
                    <option value="title">제목</option>
                </select>
                <input
                    type="text"
                    value={keyword}
                    onChange={(e) => setKeyword(e.target.value)}
                    placeholder="검색어 입력"
                />
                <button type="submit">조회</button>
                <button type="button" id="btnWrite" onClick={() => setActiveComponent("write")}>글쓰기</button>
            </form>

            <p className="board-count">{count}개의 게시물이 있습니다.</p>

            {/* 게시글 목록 */}
            <div className="board-wrapper">
                <table className="board-table" border={"1"}>
                    <thead>
                        <tr>
                            <th>번호</th>
                            <th>제목</th>
                            <th>이름</th>
                            <th>날짜</th>
                            <th>조회수</th>
                        </tr>
                    </thead>
                    <tbody>
                        {posts.length > 0 ? (
                            posts.map((row) => (
                                <tr key={row.idx}>
                                    <td>{row.idx}</td>
                                    <td>
                                        <a href="#"
                                            className="view-board"
                                            onClick={(e) => {
                                                e.preventDefault();
                                                handleTitleClick(row.idx); // ✅ 상세보기 컴포넌트로 변경
                                            }}>
                                            {row.title}
                                        </a>
                                        {row.cnt > 0 && <span style={{ color: "red" }}>({row.cnt})</span>}
                                    </td>
                                    <td>{row.name}</td>
                                    <td>{new Date(row.regdate).toLocaleString()}</td>
                                    <td>{row.hit}</td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan="5">게시물이 없습니다.</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>

            {/* 페이징 */}
            {page_info && <Pagination page_info={page_info} fetchPosts={fetchPosts} />}
        </div>
    );
};

const Pagination = ({ page_info, fetchPosts }) => {
    if (!page_info) return null;

    return (
        <div className="pagination">
            {/* 이전 버튼 */}
            {page_info.curPage > 1 && (
                <a href="#" onClick={(e) => { e.preventDefault(); fetchPosts(page_info.prevPage); }}>
                    [이전]
                </a>
            )}

            {/* 페이지 번호 */}
            {Array.from({ length: page_info.blockEnd - page_info.blockBegin + 1 }, (_, i) => {
                const num = page_info.blockBegin + i;
                return num === page_info.curPage ? (
                    <span key={num} className="active-page">{num}</span>
                ) : (
                    <a key={num} href="#" onClick={(e) => { e.preventDefault(); fetchPosts(num); }}>
                        {num}
                    </a>
                );
            })}

            {/* 다음 버튼 */}
            {page_info.curBlock <= page_info.totBlock && (
                <a href="#" onClick={(e) => { e.preventDefault(); fetchPosts(page_info.nextPage); }}>
                    [다음]
                </a>
            )}

            {/* 마지막 페이지 버튼 */}
            {page_info.curPage < page_info.totPage && (
                <a href="#" onClick={(e) => { e.preventDefault(); fetchPosts(page_info.totPage); }}>
                    [끝]
                </a>
            )}
        </div>
    );
};

export default BoardList;
