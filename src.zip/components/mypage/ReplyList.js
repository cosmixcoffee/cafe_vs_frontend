import React, { useEffect, useState } from "react";

const ReplyList = ({ comments: initialComments, selectedIdx, setSelectedComment }) => {
    const [comments, setComments] = useState(initialComments || []); // 초기값을 빈 배열로 설정
    const [pageInfo, setPageInfo] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);

    useEffect(() => {
        setComments(initialComments || []); // props로 전달된 comments가 없으면 빈 배열로 설정
    }, [initialComments]);

    useEffect(() => {
        fetchComments(currentPage);
    }, [currentPage]);

    const fetchComments = (page) => {
        fetch(`http://localhost/api/reply/list?idx=${selectedIdx}&curPage=${page}`)
            .then((response) => response.json())
            .then((data) => {
                setComments(data.list || []);  // 데이터가 없으면 빈 배열로 설정
                setPageInfo(data.page_info);
            })
            .catch((error) => console.error("댓글을 불러오는 중 오류 발생", error));
    };

    const handlePageChange = (page) => {
        setCurrentPage(page);
    };

    return (
        <div>
            <h3>댓글</h3>
            <div className="view_comments-list">
                {comments.length > 0 ? (
                    comments.map((comment) => (
                        <div key={comment.idx} className="view_comment">
                            <strong>{comment.replyer}</strong>: {comment.reply_text}
                            <button onClick={() => setSelectedComment(comment)}>수정</button>
                        </div>
                    ))
                ) : (
                    <p>댓글이 없습니다.</p>
                )}
            </div>

            {/* 페이징 처리 */}
            {pageInfo && (
                <div className="pagination">
                    {pageInfo.curPage > 1 && (
                        <button onClick={() => handlePageChange(pageInfo.prevPage)}>이전</button>
                    )}

                    {Array.from({ length: pageInfo.blockEnd - pageInfo.blockBegin + 1 }, (_, i) => {
                        const num = pageInfo.blockBegin + i;
                        return num === pageInfo.curPage ? (
                            <span key={num}>{num}</span>
                        ) : (
                            <button key={num} onClick={() => handlePageChange(num)}>
                                {num}
                            </button>
                        );
                    })}

                    {pageInfo.curPage < pageInfo.totPage && (
                        <button onClick={() => handlePageChange(pageInfo.nextPage)}>다음</button>
                    )}
                </div>
            )}
        </div>
    );
};

export default ReplyList;
