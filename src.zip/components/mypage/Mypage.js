import React, { useEffect, useState } from "react";
import Cookies from "universal-cookie";
import { useNavigate } from "react-router-dom";
import "../css/Mypage.css";
import BoardList  from "./BoardList";
import BoardWrite from "./BoardWrite";
import BoardView from "./BoardView";

const MyPage = () => {
    const navigate = useNavigate();
    const cookies = new Cookies();
    const [userInfo, setUserInfo] = useState(null);
    const [error, setError] = useState(null);
    const [activeComponent, setActiveComponent] = useState("profile");
    const [selectedIdx, setSelectedIdx] = useState(null); //게시글아이디 저장
    

    useEffect(() => { 
        const userid = cookies.get("userid");
        const user_name = cookies.get("user_name");
        const cf_number = cookies.get("cf_number");
        const user_au_lv = cookies.get("user_au_lv");


        if (!userid) {
            setError("로그인이 필요합니다.");
            return;
        }

        console.log(`🔍 쿠키에서 가져온 userid: ${userid}, user_au_lv: ${user_au_lv}`);

        fetch(`http://localhost/api/member/profile?userid=${userid}&au_lv=${user_au_lv}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error("서버 응답 오류");
                }
                return response.json();
            })
            .then(data => {
                if (data.status === "success") {
                    setUserInfo(data.user);
                } else {
                    setError(data.message);
                }
            })
            .catch(error => {
                console.error("프로필 정보를 가져오는 중 오류 발생:", error);
                setError("정보를 불러올 수 없습니다.");
            });
    }, []);

    return (
        <div className="mypage-container">
            <div className="mypage-sidebar">
                <h2>마이페이지</h2>
                <ul>
                    <li onClick={() => navigate("/mypage/edit")}>정보 수정</li>
                    {userInfo && (userInfo.au_lv === 0 || userInfo.au_lv === 1) && (
                        <>
                            <li onClick={() => navigate("/mypage/cafe/register")}>카페 등록</li>
                            <li onClick={() => navigate("/mypage/cafe/edit")}>카페 정보 수정</li>
                        </>
                    )}
                    <li onClick={() => navigate("/mypage/favorites")}>즐겨찾기한 카페</li>
                    <li onClick={() => navigate("/mypage/memos")}>메모 목록</li>
                    <li onClick={() => setActiveComponent("board")}>건의사항</li>
                    <li onClick={() => navigate("/mypage/session")}>세션 테스트</li>
                </ul>
            </div>
            <div className="mypage-content">
                {activeComponent === "board" ? (
                    <BoardList setActiveComponent={setActiveComponent} setSelectedIdx={setSelectedIdx} />  // 건의사항 리스트 
                ) : activeComponent === "write" ? (
                    <BoardWrite setActiveComponent={setActiveComponent} />  //  건의사항 글쓰기
                ) : activeComponent === "view" && selectedIdx ? (
                    <BoardView selectedIdx={selectedIdx} setActiveComponent={setActiveComponent} />  // 건의사항 상세보기 추가
                ) : activeComponent === "profile" && userInfo ? (
                    <div>
                        <h3>{userInfo.name}님 환영합니다.</h3>
                        <p>아이디: {userInfo.userid}</p>
                        <p>이메일: {userInfo.email}</p>
                        <p>연락처: {userInfo.tel}</p>
                    </div>
                ) : (
                    <p>{error || "로딩 중..."}</p>
                )}
            </div>
        </div>
    );
};

export default MyPage;
