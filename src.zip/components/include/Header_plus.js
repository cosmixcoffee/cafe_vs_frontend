import React from "react";
import Cookies from "universal-cookie";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import "../css/Header_plus.css";

function Header_plus() {
    const cookies = new Cookies();
    const navigate = useNavigate();

    const userid = cookies.get('userid');
    const user_name = cookies.get('user_name');
    const cf_number = cookies.get('cf_number');
    const user_au_lv = cookies.get('user_au_lv');

    console.log("user_au_lv:", user_au_lv);

    const removeCookie = () => {
        cookies.remove("userid", {path: '/' });
        cookies.remove("user_name", {path: '/' });
        cookies.remove("cf_number", {path: '/' });
        cookies.remove("user_au_lv", {path: '/' });
        alert("로그아웃 되었습니다.");
        navigate("/member/login");
    };

    const getUserRole = () => {
        switch (true) {
            case user_au_lv === 0:
                return `${user_name}  관리자님`;
            case user_au_lv === 1:
                return `${user_name}  매니저님`;
            case user_au_lv === 2:
                return `${user_name}  회원님`;
            default:
                return "";
        }
    };

    return (
        <div>
        <div className="Mainheader">
        <div className="Lheader">
            <Link to="메인주소링크">CAFFETITLE</Link>
        </div>
        <div className="Rheader">
            {userid ? (
                <>
                    <span>{getUserRole()}</span>
                    <span>&nbsp;&nbsp;&nbsp;|</span>
                    <Link to="/member/mypage">마이페이지</Link>
                    <span>&nbsp;&nbsp;&nbsp;|</span>
                    <button onClick={removeCookie} className="logout_btn">로그아웃</button>
                </>
            ):(<Link to="/member/login">로그인</Link>
                
            )}
            
        </div>
        </div>
        <hr />
        </div>
        
    );
}

export default Header_plus;