import React from "react";
import { Routes, Route} from "react-router";
import { BrowserRouter, useLocation  } from "react-router-dom";

import Header from './components/include/Header.js';
import Header_plus from './components/include/Header_plus.js';
import CafeLogin from './components/log/CafeLogin.js'
import LoginSuccess from './components/test.js';
import CafeJoin from "./components/log/CafeJoin.js";
import MyPage from "./components/mypage/Mypage.js";
import List from "./components/mypage/BoardList.js";


function App() {
  console.warn = function no_console() {};
  const location = useLocation(); 
  //let a='2';
  //{ a === '1' ? <Header /> : <Header_plus /> }
   // 특정 경로에서만 Header를 변경
  const isLoginPage = location.pathname === "/success" || location.pathname === "/member/join" || location.pathname === "/member/mypage";

  return (
    <>
        {isLoginPage ? <Header_plus /> : <Header />}
        <Routes>
          <Route path="/member/login" element={<CafeLogin />} />
          <Route path="/success" element={<LoginSuccess />} />
          <Route path="/member/join" element={<CafeJoin />} />
          <Route path="/member/mypage" element={<MyPage />} />
          <Route path="/member/mypage/board" element={<List />} />
        </Routes>
    </>
  );
}

// BrowserRouter를 따로 감싸서 useLocation이 정상 작동하도록 함
function AppWrapper() {
  return (
    <BrowserRouter>
      <App />
    </BrowserRouter>
  );
}

export default AppWrapper; 